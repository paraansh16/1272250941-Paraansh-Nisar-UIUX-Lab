"""Transcribe all recordings in ../audio_files into .txt files here.
Setup:  pip install openai-whisper   (also needs ffmpeg installed)
Run:    python transcribe.py
"""
import glob, os, whisper
model = whisper.load_model("small")          # use "medium" for better accuracy
for path in sorted(glob.glob("../audio_files/*")):
    name = os.path.splitext(os.path.basename(path))[0]
    text = model.transcribe(path, language="en")["text"].strip()
    open(f"{name}_transcript.txt", "w", encoding="utf-8").write(text)
    print("done:", name)
